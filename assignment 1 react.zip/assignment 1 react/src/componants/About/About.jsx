import { Component } from "react";

export class About extends Component {
    state = {
     
    }
    render() {
        return <>
            <h1>Hello from about</h1>
        </>
    }
}
import { Component } from "react";

export default class Slider extends Component {
    state = {

    }
    render() {
        return <>
        <h1 >Hello from slider</h1>
        </>
    }
}